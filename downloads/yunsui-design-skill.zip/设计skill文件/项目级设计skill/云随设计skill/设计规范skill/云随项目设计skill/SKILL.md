---
name: yunsui-design
description: 为产品经理或研发基于“乐采云随”需求文档、业务诉求和数据生成、改造或评审页面 Demo。读取已由设计师完成分级和样板沉淀的云随项目规则，复用正式 Figma 页面模式，以 UDesign 实现基础视觉交互；非核心缺失只使用云随内部补全策略，核心缺失输出设计缺口。用户提出云随页面、采购文件提取/检测、智能章节推荐、围串标审查、辅助评标、业务系统回填、长任务状态或单 HTML Demo 时使用。
---

# 乐采云随项目设计

## 使用定位

把本 Skill 视为设计师已经整理完成的云随项目生产规范。日常使用者主要是产品经理和研发：他们只需提供本 Skill 与本次需求文档、业务诉求或测试数据，由 AI 在已沉淀范围内生成 Demo。

不要要求产品经理或研发判断 L0～L3、重新整理 Figma 节点或选择组件。L0～L3 分级、复杂页面样板和项目设计规则应由设计师在发布或升级 Skill 前完成。

## 两个工作阶段

### A. 设计师建设与升级 Skill

仅在维护本 Skill 时执行：

1. 判断新模式属于 L0～L3。
2. 为 L2/L3 关键页面确认结构；L3 核心复杂页面先由设计师制作正式 Figma 样板。
3. 将正式 Figma、UDesign 映射、角色权限、页面状态和准入规则沉淀到 `knowledge/`、`ai-guides/` 或 `ai-prompts/`。
4. 用真实需求回归测试后再交给产品经理和研发使用。

L0～L3 是设计治理标签，不是产品经理或研发生成 Demo 时必须填写的输入项。

### B. 产品经理或研发日常生成 Demo

日常使用只执行：

1. 读取本 Skill 与本次需求文档、业务诉求和数据。
2. 从 Skill 中匹配业务规则、正式样板和成熟页面模式。
3. 检查需求是否落在已沉淀范围内。
4. 在范围内直接生成可运行 Demo，并补齐适用状态。
5. 超出范围时停止自行设计核心复杂页面，列出缺失样板或设计决策，反馈设计师处理。
6. 完成后自检并交付；重复问题回流设计师决定是否更新 Skill。

## 来源优先级

业务事实和设计事实分开判断，详见 [source-priority.md](ai-guides/source-priority.md)。

- 业务事实优先级：本次已确认需求 → 云随业务模型和权限规则 → 已沉淀稳定业务规则 → 待确认事项。
- 设计事实优先级：正式 Figma → 云随成熟页面模式 → UDesign 基础组件 → 云随内部补全策略。
- 正式 Figma：决定已有页面的最终布局、尺寸、间距、层级、项目视觉和页面组合。
- UDesign：提供按钮、输入、上传、标签、进度、抽屉、空状态等基础视觉交互组件和框架实现，不得覆盖 Figma。
- 云随内部补全策略：仅处理正式 Figma、UDesign 和云随成熟模式均未覆盖的非核心细节；不读取外部通用基础设计 Skill。
- 产品 Demo：只提供功能、角色、阶段和流转逻辑，不提供视觉依据。

## 开始前读取

按本次需求读取：

- 执行顺序：[execution-flow.md](ai-guides/execution-flow.md)
- 覆盖检查：[coverage-check.md](ai-guides/coverage-check.md)
- 来源优先级：[source-priority.md](ai-guides/source-priority.md)
- 输出规则：[output-rules.md](ai-guides/output-rules.md)
- 阶段、角色、服务和状态：[business-model.md](knowledge/business-model.md)
- 颜色、字体、尺寸与交互：[visual-language.md](knowledge/visual-language.md)
- UDesign 映射：[udesign-component-mapping.md](knowledge/udesign-component-mapping.md)
- UDesign 图标库：[icon-library.md](knowledge/icon-library.md)
- 项目插图与空状态：[illustration-rules.md](knowledge/illustration-rules.md)
- 页面成熟模式：[page-patterns.md](knowledge/page-patterns.md)
- 正式样板和框架参考：[figma-samples.md](knowledge/figma-samples.md)
- 非核心缺失处理：[fallback-policy.md](knowledge/fallback-policy.md)
- P0/P1/P2 与交付：[review-and-delivery.md](knowledge/review-and-delivery.md)
- 尚未稳定的范围：[open-questions.md](knowledge/open-questions.md)

需要提示词模板时读取：

- 生成 Demo：[generate-demo.md](ai-prompts/generate-demo.md)
- 评审 Demo：[review-demo.md](ai-prompts/review-demo.md)
- 设计缺口输出：[design-gap-output.md](ai-prompts/design-gap-output.md)
- 更新 Skill：[update-skill.md](ai-prompts/update-skill.md)

无需让用户再次提供已收录在 `figma-samples.md` 中的节点。AI 应自行定位和读取对应样板。

## 日常执行流程

### 1. 读取本次需求

优先从用户提供的需求文档、诉求、业务文件和测试数据中提取：

- 用户角色。
- 项目阶段。
- 云随服务。
- 页面目标与主要操作。
- 进入条件和完成条件。
- 关键业务内容。
- 期望交付形式。

能从文档和 Skill 推导的内容不要反复询问。只有缺失信息会显著改变业务结果时，才提出一个聚焦问题。

### 2. 执行覆盖范围检查

按 [coverage-check.md](ai-guides/coverage-check.md) 检查本次需求是否能由现有业务规则、正式 Figma、UDesign 映射和成熟页面模式覆盖。

- **已覆盖**：直接进入生成。
- **部分覆盖**：成熟部分直接生成；非核心缺失可按云随内部补全策略处理，并记录补全范围。
- **未覆盖或疑似全新复杂模式**：不要自行创造核心结构、权限、风险机制或项目视觉；输出“设计缺口清单”，交由设计师补充样板或规则。

覆盖范围检查是 AI 的内部执行步骤，不要求产品经理或研发先判断 L0～L3。

### 3. 建立业务上下文

使用 `角色 × 阶段 × 服务 × 状态` 路由页面：

1. 判断阶段是否允许当前服务。
2. 判断角色是否允许查看、发起、取消、重试、重新发起或回填。
3. 判断数据来自云随上传、业务系统触发还是历史记录。
4. 选择未发起、等待、排队、处理中、结果、失败、不可用、无权限或历史态。

阶段不匹配时使用“当前阶段不可用”或“历史无记录/只读记录”，不要只禁用正常页主按钮。

### 4. 复用页面和组件

1. 从 `knowledge/figma-samples.md` 和 `knowledge/page-patterns.md` 定位成熟样板。
2. 已有 Figma 节点时，读取节点设计上下文和截图，再实现和对照。
3. 将基础控件映射到 `knowledge/udesign-component-mapping.md`，但保留 Figma 布局和项目视觉。
4. 将基础图标映射到 `knowledge/icon-library.md` 指向的本地 UDesign 官方 SVG，不得自造图标。
5. 对没有正式 Figma 插图的空状态、成功、失败、网络异常、维护等通用状态，按 `knowledge/illustration-rules.md` 使用 UDesign Empty 或云随中性占位，保持 Demo 完整性。
6. 标为“框架参考”的线上 AI 截图只参考信息架构。
7. 只有非核心缺失部分才进入 `knowledge/fallback-policy.md`；若仍无法覆盖，输出设计缺口。

### 5. 补齐适用状态

AI 长任务至少检查：

`未发起 → 材料准备/外部触发等待 → 排队 → 处理中 → 成功结果`

并按业务补充：

`取消、可恢复失败、超时失败、无权限、阶段不可用、历史有记录、历史无记录、离开或关闭后的处理`。

Loading 必须展示当前任务、业务进度、是否可离开和失败恢复路径，禁止只有无限旋转动画。

### 6. 生成 Demo

用户要求 Demo 或 HTML 时，默认交付一份内联 CSS/JS、双击可打开、断网可运行的单 HTML。

- 不创建 React、Vite、Vinext 或其他工程脚手架。
- 已有 Figma 页面按正式样板实现。
- 图标只使用本地 UDesign 官方 SVG，并仅内联本次实际用到的图标。
- 缺少正式项目插图时，按插图兜底规则生成完整 Demo，不因普通空状态缺图而中断。
- 测试数据优先使用用户提供的业务文件或需求数据。
- 覆盖需求涉及的完整路径和关键状态。
- 若需要身份、项目阶段、页面状态或快捷入口切换，将其做成独立的外置演示控制台。控制台可底部悬浮、可隐藏，但不得作为云随业务页面的一部分、不得挤占页面主体布局、不得让用户误以为是正式功能。

只有用户明确要求工程化实现时，才创建项目结构。

### 7. 自检和交付

按 `knowledge/review-and-delivery.md` 执行 P0/P1/P2 自检。

日常默认交付保持简洁：

1. 可运行 Demo 或修改后的文件。
2. 已覆盖的页面与状态。
3. 关键假设或产品待确认项。
4. 设计缺口（没有则不输出）。
5. P0/P1/P2 结论。

除非用户要求设计说明，不先输出冗长的组件清单和分级报告再开始生成。

## 设计缺口处理

出现以下任一情况时，停止自行扩展核心页面：

- 新增业务阶段或新角色工作台。
- 新首页骨架或全新核心流程。
- 新的高风险、不可逆操作。
- 新的风险判断机制或关键结果交互。
- 正式样板不足以确定核心布局和项目视觉。
- 角色、阶段、权限或数据来源存在实质冲突。
- 插图本身承载核心业务含义、风险解释或强品牌主视觉，且没有正式样板或项目资产。

输出：

```markdown
## 设计缺口
- 已能复用的部分：
- 缺失的核心页面或状态：
- 需要设计师确认的规则：
- 建议补充的 Figma 样板：
- 可先生成的非核心部分：
- 暂停生成的原因：
```

完整模板见 [design-gap-output.md](ai-prompts/design-gap-output.md)。

## AI 结果与回填

- 二级 AI 页面保留“内容由 AI 生成，结果仅供参考”。
- 风险检测和评审结论可追溯到依据、来源或原文位置。
- 回填内容显示“AI已回填”，并允许人工核验和修改（业务明确禁止时除外）。
- 一次性提取结果若关闭即丢失，操作前必须提示。
- 高风险、不可逆或影响宿主数据的操作必须有确认和恢复路径。

## 术语与稳定规则

- 正式阶段术语：`文件编制`、`开标流程`。
- 正式服务术语：`围串标审查`。
- 上传支持常用 `PDF / DOC / DOCX` 等格式，单次最大 `2GB`。
- 不限制采购类型；角色与权限按业务模型执行。

## 禁止项

- 不要求产品经理或研发先判断 L0～L3。
- 不要求用户重复提供 Skill 已收录的 Figma 节点。
- 不把产品 Demo 当作视觉规范。
- 不用 UDesign 默认组合替换已有 Figma 页面。
- 不在已有 Figma、UDesign 或成熟模式已覆盖时启动云随内部补全策略。
- 不在缺少核心样板时自行设计复杂页面。
- 不省略失败、超时、权限、历史和离开后的处理。
- 不在用户只要求单 HTML 时创建工程脚手架。
- 不把用于 Demo 的身份、阶段、状态切换器放进业务页面内容区。

## Skill 维护

产品或研发反馈的问题先记录，由设计师判断是否回灌。只有同类问题重复出现、形成跨服务稳定模式、正式业务规则变化或新增正式样板时才更新 Skill。更新后分别用成熟单一模式和成熟组合模式的真实需求回归测试。
